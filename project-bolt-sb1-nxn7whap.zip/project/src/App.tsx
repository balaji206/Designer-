import React, { useState } from 'react';
import { Menu, Plus, Globe2 } from 'lucide-react';

function App() {
  const [message, setMessage] = useState('');

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-purple-950 to-purple-900">
      {/* Header */}
      <header className="fixed top-0 w-full p-4 flex items-center justify-between z-50">
        <div className="flex items-center gap-4">
          <Menu className="w-6 h-6 text-gray-400 cursor-pointer hover:text-white transition-colors" />
          <div className="relative group">
            <button className="text-white text-xl font-bold flex items-center gap-2">
              STYLUX
              <span className="ml-1 inline-block transform group-hover:rotate-180 transition-transform duration-200">▼</span>
            </button>
          </div>
        </div>
        <button className="bg-purple-500 hover:bg-purple-600 text-white px-6 py-2 rounded-full transition-colors">
          Try for free
        </button>
      </header>

      {/* Sidebar */}
      <aside className="fixed left-0 top-0 h-screen w-48 bg-[#111111] p-4">
        <div className="space-y-6 mt-16">
          <div className="flex items-center gap-3 text-gray-300 hover:text-white cursor-pointer transition-colors">
            <Menu className="w-5 h-5" />
            <span>STYLUX</span>
          </div>
          <div className="flex items-center gap-3 text-gray-300 hover:text-white cursor-pointer transition-colors">
            <Globe2 className="w-5 h-5" />
            <span>Explore STYLUX</span>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="ml-48 pt-24 flex flex-col items-center justify-center min-h-screen p-4">
        <h1 className="text-white text-5xl font-bold mb-16 text-center">
          What can I help you with?
        </h1>
        
        <div className="w-full max-w-2xl relative">
          <div className="bg-[#1a1a1a]/80 rounded-2xl p-6 backdrop-blur-sm">
            <div className="flex items-start gap-4">
              <button className="p-2 rounded-full hover:bg-gray-700/50 transition-colors">
                <Plus className="w-6 h-6 text-gray-400" />
              </button>
              <textarea
                className="flex-1 bg-transparent text-white placeholder-gray-400 resize-none outline-none"
                placeholder="Message STYLUX"
                rows={1}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
              />
              <div className="flex gap-2">
                <button className="px-4 py-2 text-gray-300 hover:text-white border border-gray-600 rounded-full flex items-center gap-2 transition-colors">
                  <Globe2 className="w-4 h-4" />
                  Browse
                </button>
                <button className="px-6 py-2 bg-purple-500 hover:bg-purple-600 text-white rounded-full transition-colors">
                  Generate
                </button>
              </div>
            </div>
          </div>
          
          <p className="text-gray-400 text-sm mt-4 text-center">
            By clicking "Generate" you agree to generate.{' '}
            <a href="#" className="text-purple-400 hover:text-purple-300 transition-colors">
              Privacy Notice
            </a>
          </p>
        </div>
      </main>
    </div>
  );
}

export default App;